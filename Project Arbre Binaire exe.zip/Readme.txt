1- Extraire l'archive dans un nouveau dossier
2- verifer que le racourcie Algo.exe et le dossier Algo soit dans le même sous dossier
3- Lancer l'exe (En cas de non fonctionnement installer Python 3 avec le module dans l'archive
Enjoy :) 
